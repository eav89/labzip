from django.shortcuts import render
from django import template

def home(request):
    return render(request, 'templates/index.html')

#from django.http import HttpResponse
#def home(request):
#    return HttpResponse(u'Привет, Мир!')
#    return HttpResponse(u'Привет, Мир!', content_type="text/plain")

